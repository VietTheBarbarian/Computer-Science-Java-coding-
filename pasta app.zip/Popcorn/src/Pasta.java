
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nhu Viet Nguyen
 */
public class Pasta {
   private String size;
   private String noodle;
   private String sauce;
   private String protein;
   private boolean shreddedParm;
 private  String mixed;
 String messages;

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getNoodle() {
        return noodle;
    }

    public void setNoodle(String noodle) {
        this.noodle = noodle;
    }

    public String getSauce() {
        return sauce;
    }

    public void setSauce(String sauce) {
        this.sauce = sauce;
    }

    public String getProtein() {
        return protein;
    }

    public void setProtein(String protein) {
        this.protein = protein;
    }

    public boolean isShreddedParm() {
        return shreddedParm;
    }

    public void setShreddedParm(boolean shreddedParm) {
        this.shreddedParm = shreddedParm;
    }

    public String getMixed() {
        return mixed;
    }

    public void setMixed2(String mixed2) {
        this.mixed = mixed;
    }

    public Pasta(String size, String noodle, String sauce, String protein, boolean shreddedParm, String mixed, String messages) {
        this.size = size;
        this.noodle = noodle;
        this.sauce = sauce;
        this.protein = protein;
        this.shreddedParm = shreddedParm;
        this.mixed = mixed;
        this.messages=messages;
    }

    @Override
    public String toString() {
        return "Your noodle is" +noodle+ ". Your size is " +size+ ". Your sauce is "+sauce+ ". Your protein is "+protein+ " Your choice of parm is " +shreddedParm + ". Your choice of mix is " +mixed+ " Your message is"+messages+"." ;
    }



   



    
   
 
   
    
    
}
